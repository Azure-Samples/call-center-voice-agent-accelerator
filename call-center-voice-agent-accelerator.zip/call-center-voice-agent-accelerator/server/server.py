import asyncio
import json
import logging
import os

from app.handler.voice_live_handler import VoiceLiveStreamingHandler
from app.handler.twilio_handler import TwilioMediaStreamHandler
from dotenv import load_dotenv
from quart import Quart, websocket

load_dotenv()

app = Quart(__name__)
app.config["AZURE_VOICE_LIVE_API_KEY"] = os.getenv("AZURE_VOICE_LIVE_API_KEY", "")
app.config["AZURE_VOICE_LIVE_ENDPOINT"] = os.getenv("AZURE_VOICE_LIVE_ENDPOINT")
app.config["VOICE_LIVE_MODEL"] = os.getenv("VOICE_LIVE_MODEL", "gpt-4o-mini")
app.config["AZURE_USER_ASSIGNED_IDENTITY_CLIENT_ID"] = os.getenv(
    "AZURE_USER_ASSIGNED_IDENTITY_CLIENT_ID", ""
)

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s: %(message)s"
)


@app.websocket("/web/ws")
async def web_ws():
    """WebSocket endpoint for web clients to send audio to Voice Live."""
    logger = logging.getLogger("web_ws")
    logger.info("Incoming Web WebSocket connection")
    handler = VoiceLiveStreamingHandler(app.config, enable_responses=True)

    async def send_user_transcript(text: str) -> None:
        payload = {"Kind": "Transcription", "Speaker": "user", "Text": text}
        await websocket.send(json.dumps(payload))

    async def send_ai_transcript(text: str) -> None:
        payload = {"Kind": "Transcription", "Speaker": "assistant", "Text": text}
        await websocket.send(json.dumps(payload))

    async def send_audio_chunk(chunk: bytes) -> None:
        await websocket.send(chunk)

    async def send_stop_signal() -> None:
        await websocket.send(json.dumps({"Kind": "StopAudio"}))

    handler.register_event_handlers(
        on_user_transcript=send_user_transcript,
        on_ai_transcript=send_ai_transcript,
        on_audio_chunk=send_audio_chunk,
        on_audio_stop=send_stop_signal,
    )

    await handler.start()
    try:
        while True:
            msg = await websocket.receive()
            if isinstance(msg, (bytes, bytearray)):
                await handler.send_pcm16(bytes(msg))
            else:
                logger.debug("Ignoring non-binary message from web client")
    except asyncio.CancelledError:
        raise
    except Exception:
        logger.exception("Web WebSocket connection closed")
    finally:
        await handler.close()


@app.websocket("/twilio/stream")
async def twilio_stream():
    """WebSocket endpoint for Twilio Media Streams to deliver audio for transcription."""

    logger = logging.getLogger("twilio_stream")
    logger.info("Incoming Twilio WebSocket connection")

    handler = VoiceLiveStreamingHandler(app.config, enable_responses=False)
    twilio_handler = TwilioMediaStreamHandler(websocket, handler)

    handler.register_event_handlers(
        on_user_transcript=twilio_handler.send_user_transcript,
        on_ai_transcript=twilio_handler.send_ai_transcript,
    )

    await handler.start()
    try:
        while True:
            msg = await websocket.receive()
            await twilio_handler.handle_message(msg)
    except asyncio.CancelledError:
        raise
    except Exception:
        logger.exception("Twilio WebSocket connection closed")
    finally:
        await handler.close()


@app.route("/")
async def index():
    """Serves the static index page."""
    return await app.send_static_file("index.html")


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=8000)
